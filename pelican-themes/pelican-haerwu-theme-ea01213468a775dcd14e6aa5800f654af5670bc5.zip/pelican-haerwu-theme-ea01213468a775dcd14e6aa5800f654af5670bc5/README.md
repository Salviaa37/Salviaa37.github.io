# Haerwu

Haerwu is a theme for the Pelican static site generator. Inspired by
[Spacious](https://themegrill.com/themes/spacious/) theme for WordPress.


# Live example

I use this theme on my [personal
blog](https://marcin.juszkiewicz.com.pl/).


# Installation

[Pelican-Docs](https://docs.getpelican.com/en/stable/) will guide you through the initial installation.


## Plugins

There is support for several plugins:

- neighbors
- related_posts
- series


